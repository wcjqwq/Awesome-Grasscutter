// This is just for testing purposes.
// Used to refresh the page.

const update = document.createElement('div');
update.id = 'update-button';
update.classList.add('TopButton');
update.innerHTML = '<p>Update</p>';


document.body.appendChild(update);

document.getElementsByClassName("TopBtns")[0].appendChild(update);

update.addEventListener('click', function() {
    window.location.reload();
});