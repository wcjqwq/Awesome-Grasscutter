document.getElementsByClassName('image')[0].innerHTML += '<div class="bodyyae"><img src="https://alt3ri.com/img/longyae/body.png" width="100" height="135" style="vertical-align:middle"></div>'
document.getElementsByClassName('image')[0].innerHTML += '<div class="headyae"><img src="https://alt3ri.com/img/longyae/part.png" width="85" height="80" style="vertical-align:middle"></div>'
document.getElementsByClassName('image')[0].innerHTML += '<div class="yae"><img src="https://alt3ri.com/img/yae.png" width="100" height="100" style="vertical-align:middle"></div>'
document.getElementsByClassName('bg')[0].innerHTML += '<div class="videobg"><video autoplay muted loop id="myVideo"><source src="https://alt3ri.com/img/yae.mp4" type="video/mp4"></video></div>';
/*function play() {
    var audio = new Audio("https://alt3ri.com/other/music/yae.mp3");
    audio.play();
}
play();*/