const discordElm = document.createElement('div')
discordElm.id = 'Discord'
discordElm.innerHTML = 'https://discord.gg/forgor'

const img = document.createElement('img')
img.src = 'https://cdn.discordapp.com/avatars/508814821005721600/9d8f7ae02d16b2566ac0352b9aed4b90.webp?size=100'

discordElm.appendChild(img);

document.body.appendChild(discordElm)