// Set title
document.querySelector('#title').firstChild.innerHTML = 'Colleivation';

// Add lil collei
var collei = document.createElement('img');
collei.src = 'https://cdn.discordapp.com/attachments/720812218484129904/999840986031210598/unknown.png';
collei.style.width = '100px';
collei.style.height = '100px';
collei.style.position = 'absolute';
collei.style.bottom = '0';
collei.style.left = '10px';
collei.style.zIndex = '999';

document.body.appendChild(collei);